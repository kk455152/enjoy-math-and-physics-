"""Read existing results only; no COMSOL solve and no repository changes."""
import json
import math
from pathlib import Path

ROOT = Path(r'F:\磁力木马\enjoy-math-and-physics-')
OUT = Path(__file__).parent

def table(path):
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    header = next(x for x in lines if x.startswith('% t_s')).lstrip('% ').split()
    row = next(x for x in lines if x.strip() and not x.startswith('%'))
    return dict(zip(header, map(float, row.split())))

results = {}
for material in ['GCr15_hardened', 'GCr15_annealed', 'PC40', 'H62']:
    directory = ROOT / '时变磁场模型/通用瞬态耦合/results' / ('branch_v8_' + material + '_N10')
    config = json.loads((directory / 'input_parameters.json').read_text(encoding='utf-8-sig'))
    data = table(directory / 'total_force_history.txt')
    results[material] = {'source': str(directory / 'total_force_history.txt'), 'configuration': config, 't0': data}

frozen = json.loads((ROOT / '连续磁力地图/统一参数模型/GCr15_hardened_N10_R96.json').read_text(encoding='utf-8-sig'))
row = next(x for x in frozen['training'] if x['coordinates'] == [0, 0, 6, 10])
langevin = lambda x: 1 / math.tanh(x) - 1 / x
axis = langevin(10)
diagonal = math.sqrt(2) * langevin(10 / math.sqrt(2))
evidence = {
    'method': 'Read native COMSOL export tables; analytic constitutive counterexample; no new finite-element solve.',
    'archived_N10_initial_results': results,
    'static_N10_same_geometry': {k: row[k] for k in ['coordinates', 'source_force']},
    'static_N10_force_xyz_N': row['values'][:3],
    'transient_to_static_abs_Fx_ratio': abs(results['GCr15_hardened']['t0']['Fx_total_N'] / row['values'][0]),
    'componentwise_Langevin_rotation_test': {
        'fixed_effective_field_norm_div_a': 10,
        'axis_M_norm_div_Ms': axis,
        'xy45deg_M_norm_div_Ms': diagonal,
        'relative_change': diagonal / axis - 1,
        'qualification': 'Analytic backbone test, not a measured FEM force error. Equal diagonal coefficients with componentwise Langevin are not rotationally isotropic.'
    },
}
(OUT / '物理核心数值证据.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in evidence.items() if k != 'archived_N10_initial_results'}, ensure_ascii=False, indent=2))
