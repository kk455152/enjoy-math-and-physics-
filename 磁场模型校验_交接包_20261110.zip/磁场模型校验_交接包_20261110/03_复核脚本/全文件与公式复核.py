"""Read-only repository audit. All reports are written outside the repository."""
from pathlib import Path
import ast, collections, csv, hashlib, io, json, math, os, re, sys, zipfile
import xml.etree.ElementTree as ET

ROOT = Path(r'F:\磁力木马\enjoy-math-and-physics-')
OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True

def dump(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def inventory():
    records=[]; archives=[]; errors=[]; duplicates=collections.defaultdict(list)
    counts=collections.Counter(); java_versions=collections.defaultdict(list)
    for folder, dirs, names in os.walk(ROOT):
        dirs[:]=sorted(d for d in dirs if d!='.git')
        for name in sorted(names):
            p=Path(folder)/name; rel=p.relative_to(ROOT).as_posix(); ext=p.suffix.lower()
            h=hashlib.sha256()
            with p.open('rb') as f:
                head=f.read(512); h.update(head)
                for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
            sha=h.hexdigest(); counts[ext]+=1; duplicates[sha].append(rel)
            checks=['已读取全部字节并记录SHA256']; note='物理结论需按所属计算链核查'
            try:
                if head.startswith(b'version https://git-lfs.github.com/spec/v1'):
                    checks.append('Git LFS指针，不是真实文件内容'); note=p.read_text().strip()
                elif ext in ('.mph','.zip'):
                    with zipfile.ZipFile(p) as z:
                        bad=z.testzip()
                        if bad: raise ValueError('CRC失败:'+bad)
                        record={'path':rel,'entries':len(z.infolist()),'crc':'PASS'}
                        if ext=='.mph':
                            record['version']=z.read('fileversion').decode(errors='replace')
                            record['solutions']=[{'name':i.filename,'bytes':i.file_size} for i in z.infolist() if i.filename.startswith('solution')]
                            xmls=[i.filename for i in z.infolist() if i.filename.endswith('.xml')]
                            for xml in xmls: ET.fromstring(z.read(xml))
                            record['xml_parsed']=xmls
                            checks.append('MPH压缩内容CRC与XML可解析；未由COMSOL重算')
                        else:
                            record['members']=[i.filename for i in z.infolist()]
                            checks.append('ZIP全部成员CRC通过；不是独立物理认证')
                        archives.append(record)
                elif ext=='.json':
                    obj=json.loads(p.read_text(encoding='utf-8-sig')); checks.append('JSON解析通过')
                    def nonfinite(v):
                        if isinstance(v,float): return not math.isfinite(v)
                        if isinstance(v,dict): return any(nonfinite(x) for x in v.values())
                        if isinstance(v,list): return any(nonfinite(x) for x in v)
                        return False
                    if nonfinite(obj): checks.append('含非有限数值，需按字段辨识占位或错误')
                elif ext=='.py':
                    ast.parse(p.read_text(encoding='utf-8-sig'),filename=rel); checks.append('Python语法解析通过')
                elif ext=='.java':
                    text=p.read_text(encoding='utf-8-sig')
                    norm=re.sub(r'(?m)^\s*static String\[\]\[\] (?:CONFIG_ENTRIES|TRAJECTORY_ENTRIES|RUN_POINTS) = .*?;\s*$', '',text)
                    jhash=hashlib.sha256(norm.encode()).hexdigest(); java_versions[jhash].append(rel)
                    checks.append('UTF8可读；按移除注入参数后的源码分组')
                elif ext in ('.txt','.csv','.md','.ps1','.log','.out','.err','.stdout','.stderr','.properties','.status','.gitattributes','.gitignore'):
                    b=p.read_bytes()
                    try: text=b.decode('utf-8-sig'); enc='UTF8'
                    except UnicodeDecodeError: text=b.decode('gb18030',errors='replace'); enc='GB18030/替换'
                    checks.append(enc+'文本扫描')
                    if ext=='.csv':
                        rows=list(csv.reader(io.StringIO(text)))
                        checks.append('CSV可解析:'+str(len(rows))+'行')
                    if ext=='.txt' and ('_force' in name or '_height_field' in name):
                        rows=[l.split() for l in text.splitlines() if l.strip() and not l.lstrip().startswith('%')]
                        nums=[[float(v) for v in row] for row in rows]
                        if any(not math.isfinite(x) for row in nums for x in row): raise ValueError('力/场数值含非有限数')
                        checks.append('力/场数值可解析且有限:'+str(len(rows))+'行')
                else:
                    note='编译/运行辅助文件；已校验字节，不作为独立物理结果'
            except Exception as e:
                checks.append('异常:'+str(e)); errors.append({'path':rel,'error':str(e)})
            records.append({'文件':rel,'字节数':p.stat().st_size,'SHA256':sha,'检查':';'.join(checks),'范围说明':note})
    with (OUT/'当前仓库_逐文件检查清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    summary={'file_count':len(records),'bytes':sum(r['字节数'] for r in records),'extensions':dict(counts),'errors':errors,
             'archives':archives,'duplicate_groups':[v for v in duplicates.values() if len(v)>1],
             'normalized_java_source_groups':list(java_versions.values()),
             'scope':'当前本地工作树，包括隐藏构建目录；不含.git内部对象；CRC和可解析性不等于物理正确'}
    dump('全文件检查证据.json',summary)
    print(json.dumps({k:summary[k] for k in ('file_count','bytes','extensions','errors')},ensure_ascii=False),flush=True)

def probes():
    sys.path.insert(0,str(ROOT/'动力学电磁接口'))
    import stepwise_em_model as s
    evidence={}
    reversals=[]
    for mat,p in s.JA_PARAMETERS.items():
        old=s.MagnetizationPoint()
        # Fine monotonic ramp, then a small reversal; use the repository function unchanged.
        for i in range(1,1001):
            H=p.a_Apm*i/1000
            mirr,m=s._advance_component(H,old,0,p)
            old=s.MagnetizationPoint([H,0,0],[mirr,0,0],[m,0,0])
        H2=old.H_Apm[0]-p.a_Apm/1000
        ir2,m2=s._advance_component(H2,old,0,p)
        reversals.append({'material':mat,'H_before':old.H_Apm[0],'H_after':H2,'M_before':old.M_Apm[0],
            'M_after':m2,'delta_M':m2-old.M_Apm[0],'delta_M_over_delta_H':(m2-old.M_Apm[0])/(H2-old.H_Apm[0]),
            'irreversible_before':old.M_irr_Apm[0],'irreversible_after':ir2})
    evidence['reversal']=reversals
    # An exactly self-consistent, held state must remain fixed in a rate-independent model.
    # Here test the repository's actual zero-M initializer in a nonzero static field.
    holds=[]
    for mat,p in s.JA_PARAMETERS.items():
        old=s.MagnetizationPoint([p.a_Apm,0,0],[0,0,0],[0,0,0]); vals=[0.]
        for _ in range(5):
            ir,m=s._advance_component(p.a_Apm,old,0,p)
            vals.append(m); old=s.MagnetizationPoint([p.a_Apm,0,0],[ir,0,0],[m,0,0])
        holds.append({'material':mat,'constant_H_Apm':p.a_Apm,'M_by_calls':vals})
    evidence['constant_field_initializer']=holds
    src=(ROOT/'静磁力地图'/'SphereMaterialCarouselModel.java').read_text(encoding='utf-8')
    bh=[]
    for method in ('gcr15AnnealedTable','gcr15HardenedTable','pc40Table'):
        body=src.split('static String[][] '+method+'()')[1].split('\n  }')[0]
        pairs=[tuple(map(float,v)) for v in re.findall(r'\{"([0-9.]+)",\s*"([0-9.]+)"\}',body)]
        h0,b0=pairs[-2];h1,b1=pairs[-1]; slope=(b1-b0)/(h1-h0)
        bh.append({'method':method,'last_points':pairs[-2:],'last_slope_T_m_A':slope,'relative_differential_permeability':slope/s.MU0,
                   'M_at_last_two_Apm':[b0/s.MU0-h0,b1/s.MU0-h1],
                   'extrapolated_at_H_1e7_Apm':{'B_T':b1+slope*(1e7-h1),'M_Apm':(b1+slope*(1e7-h1))/s.MU0-1e7}})
    evidence['BH_tail']=bh
    from scipy.optimize import brentq
    p=s.JA_PARAMETERS['GCr15_hardened']; h=p.a_Apm
    m=brentq(lambda M:M-p.Ms_Apm*s._langevin((h+p.alpha*M)/p.a_Apm),0,p.Ms_Apm)
    class RotatingUniformField:
        def query_lab(self,*args):
            return dict(Fx_N=0.,Fy_N=0.,Fz_N=0.,u_mm=0.,v_mm=0.,magnet_index=0,force_policy='synthetic_consistency_probe')
        def centerline_lab(self,material,N,R,g,D,x,y,angle,eta,**kwargs):
            return dict(Hx_Apm=h*math.cos(angle),Hy_Apm=h*math.sin(angle),Hz_Apm=0.,
                        Bx_T=s.MU0*(h+m)*math.cos(angle),By_T=s.MU0*(h+m)*math.sin(angle),Bz_T=0.)
    model=s.StepwiseElectromagneticModel(RotatingUniformField(),material='GCr15_hardened',N=4,R_mm=41,g_mm=3,D_mm=3)
    omega=10.; dt=.0001; angle=omega*dt
    state0=s.DynamicState(0,41,0,0,omega*.041,0,omega,omega)
    memory=model.initialize(state0,initial_M_Apm=[[m,0,0] for _ in s.ETAS],initial_condition='self_consistent_anhysteretic')
    co=[]
    for i in range(1,6):
        angle=omega*dt*i; x=.041*math.cos(angle);y=.041*math.sin(angle)
        state1=s.DynamicState(dt*i,x*1000,y*1000,-omega*y,omega*x,angle,omega,omega)
        result,memory=model.trial_step(state1,memory)
        co.append({k:result[k] for k in ('t_s','Physteresis_pin_est_W','Fhysteresis_loss_xyz_N','Thysteresis_loss_z_Nm','relative_velocity_xy_m_s','relative_spin_z_rad_s')})
    evidence['corotating_uniform_field_synthetic']={'steps':co,'purpose':'合成一致性反例，不是有限元或实验结果；球与均匀外场刚性同转，球材料坐标中的H恒定'}
    evidence['vector_scalar_backbone']={'He_magnitude_over_a':10.,'scalar_M_norm_over_Ms':s._langevin(10),
          'componentwise_45degree_M_norm_over_Ms':math.sqrt(2)*s._langevin(10/math.sqrt(2)),
          'scope':'按COMSOL文档的逐分量Langevin与Java标量骨干做公式对照；不是实际力误差'}
    dump('公式定向复现实验.json',evidence)
    print(json.dumps(evidence,ensure_ascii=False,indent=2),flush=True)

def native_models():
    allrows=[]
    for p in sorted(ROOT.rglob('*.mph')):
        with zipfile.ZipFile(p) as z: e=ET.fromstring(z.read('dmodel.xml'))
        params={v.attrib['name']:v.attrib.get('expr') for v in e.findall('./ModelParam/expressions')}
        def number(key, default=0):
            return float(re.match(r'[-+0-9.eE]+', params.get(key,str(default))).group())
        phys=[]; geoms=[]; materials=[]
        for n in e.iter('PhysicsFeature'):
            if re.fullmatch(r'pm\d+|ballcond|ballbh|force|zero|gauge',n.attrib.get('tag','')):
                desired=('ConstitutiveRelationBH','normBr_crel_BH_RemanentFluxDensity','e_crel_BH_RemanentFluxDensity',
                         'GPorder','M0','TorqueRotationPoint','Vm0','MsJA_mat','aJA_mat','cJA_mat','kJA_mat')
                phys.append({'tag':n.attrib['tag'],'op':n.attrib.get('op'),
                             'params':{x.attrib['param']:x.attrib['value'] for x in n.findall('param') if x.attrib.get('param') in desired},
                             'selection':n.findtext('selection/named')})
        for n in e.iter('GeomFeature'):
            tag=n.attrib.get('tag','')
            if re.fullmatch(r'mag\d+|ball',tag):
                key=n.findtext('key',''); pos=re.search(r'postypecoordpos([^|]+)\|([^|]+)\|([^|]+)\|',key)
                record={'tag':tag,'properties':{v.attrib.get('name'):v.attrib for v in n.findall('propertyValue') if v.attrib.get('name') in ('p:pos','p:r','p:rot','p:size','p:lx','p:ly','p:lz')}}
                if pos:
                    record['built_center_m']=list(map(float,pos.groups()))
                    if tag.startswith('mag'):
                        j=int(tag[3:]); angle=math.radians(number('theta0',90)+360*j/number('Ncount'))+number('alpha0')
                        expected=[number('Rring')/1000*math.cos(angle),number('Rring')/1000*math.sin(angle),number('Tmag')/2000]
                        record['expected_center_m']=expected
                        record['center_error_mm']=1000*math.dist(record['built_center_m'],expected)
                geoms.append(record)
        for n in e.iter('Material'):
            if n.attrib.get('tag')=='ballmat':
                for g in n.iter('PropertyGroup'):
                    materials.append({'tag':g.attrib.get('tag'),'xml':ET.tostring(g,encoding='unicode')[:1000]})
        checks=[]
        npms=sum(bool(re.fullmatch('pm[0-9]+',r['tag'])) for r in phys)
        if npms!=int(number('Ncount')): checks.append('永磁体物理节点数与Ncount不符')
        maxpos=max((g.get('center_error_mm',0) for g in geoms),default=None)
        if maxpos and maxpos>1e-5: checks.append('已构建磁铁中心与应有等间隔圆周位置不符')
        for node in phys:
            if re.fullmatch('pm[0-9]+',node['tag']):
                sign='1' if int(node['tag'][2:])%2==0 else '-1'
                if node['params'].get('e_crel_BH_RemanentFluxDensity')!="3|1,'0'|1,'0'|1,'"+sign+"'":
                    checks.append('磁极方向与±z交替约定不同:'+node['tag'])
        allrows.append({'file':p.relative_to(ROOT).as_posix(),'parameters':params,'magnet_count':npms,
                        'max_center_error_mm':maxpos,'checks':checks,'geometry':geoms,'physics':phys})
    dump('MPH实际节点核查.json',allrows)
    with (OUT/'MPH逐模型核查表.csv').open('w',encoding='utf-8-sig',newline='') as f:
        cols=['文件','N','R_mm','球径_mm','剩磁','最大磁铁位置偏差_mm','磁化关系','发现','范围']
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
        for r in allrows:
            p=r['parameters']; law=next((n['params'].get('ConstitutiveRelationBH') for n in r['physics'] if n['tag'] in ('ballbh','ballcond')),'默认/非磁')
            w.writerow(dict(zip(cols,[r['file'],r['magnet_count'],p.get('Rring'),p.get('Dball'),p.get('Brmag'),r['max_center_error_mm'],law,';'.join(r['checks']) or '所查节点未发现偏差','读取MPH内部XML和已构建几何坐标；未重求解'])) )
    print(json.dumps({'mph_count':len(allrows),'flagged':[{'file':r['file'],'checks':r['checks'],'max_center_error_mm':r['max_center_error_mm']} for r in allrows if r['checks']]},ensure_ascii=False),flush=True)

def static_algebra():
    root=ROOT/'静磁力地图'/'全状态补算_20261029'/'results'
    def read(p):
        head=None;ans=[]
        for line in p.read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('%'):
                v=line[1:].split()
                if v and v[0]=='N':head=v
            elif line.strip() and head:ans.append(dict(zip(head,map(float,line.split()))))
        return ans
    maxima={}; errors=[]; identities=collections.defaultdict(float)
    for path in sorted(root.rglob('*_height_field.txt')):
        mat=next((s for s in ('gcr15_hardened','gcr15_annealed','pc40','h62') if s in path.name),'unknown')
        result=maxima.setdefault(mat,{'H_max_Apm':0.,'B_max_T':0.,'rows':0})
        for r in read(path):
            H=math.sqrt(sum(r[k]**2 for k in ('Hx_Apm','Hy_Apm','Hz_Apm')))
            B=math.sqrt(sum(r[k]**2 for k in ('Bx_T','By_T','Bz_T')))
            if H>result['H_max_Apm']:result['H_max_Apm']=H;result['H_source']=path.relative_to(ROOT).as_posix()
            result['B_max_T']=max(result['B_max_T'],B);result['rows']+=1
    positive=[]
    for path in sorted(root.rglob('*_force.txt')):
        for r in read(path):
            t=math.radians(90+r['delta_deg']);fx=r['Fx_N'];fy=r['Fy_N']
            fr=fx*math.cos(t)+fy*math.sin(t);ft=-fx*math.sin(t)+fy*math.cos(t)
            for key,value in [('Fr_orbit_N',fr),('Ftheta_orbit_N',ft),('Tz_axis_Nm',r['rho_mm']/1000*ft+r['Tz_Nm'])]:
                identities[key]=max(identities[key],abs(r[key]-value))
            if 'h62' not in path.name and r['Fz_N']>1e-8:positive.append({'file':path.relative_to(ROOT).as_posix(),'Fz_N':r['Fz_N']})
    data={'centerline_maxima':maxima,'cartesian_polar_torque_max_abs_difference':dict(identities),
          'magnetic_points_with_positive_Fz_above_1e_minus8_N':positive,
          'scope':'仅当前补算目录静磁表；中心线最大值不是全体积最大值；代数吻合不是FEM收敛'}
    dump('静磁公式与场范围复核.json',data); print(json.dumps(data,ensure_ascii=False,indent=2))

if __name__=='__main__':
    if '--inventory' in sys.argv: inventory()
    if '--probes' in sys.argv: probes()
    if '--mph' in sys.argv: native_models()
    if '--static' in sys.argv: static_algebra()
