"""Verify the immutable file inventory and main audit flags in a delivery tree."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath


def main() -> None:
    root = Path(__file__).resolve().parent
    manifest_path = root / "SHA256_交付清单.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not manifest:
        raise SystemExit("交付清单为空")
    problems = []
    for name, expected in manifest.items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts:
            problems.append(f"非法路径: {name}")
            continue
        path = root.joinpath(*relative.parts)
        if not path.is_file():
            problems.append(f"缺失: {name}")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            problems.append(f"哈希不匹配: {name}")
    audit_path = root / "动力学仿真" / "results_coupled" / "coupled_audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    checks = audit.get("model_internal_delivery_checks", {})
    if not audit.get("model_internal_delivery_ready") or not checks or not all(checks.values()):
        problems.append("模型内部验收门槛未通过")
    if len(audit.get("finest_fulltime_pairs", [])) != 6:
        problems.append("最细完整轨迹对不是六组")
    if audit.get("all_experimental_validation_complete"):
        problems.append("实验状态与交付说明不符")
    if problems:
        for problem in problems:
            print(problem)
        raise SystemExit(1)
    print(f"交付校验通过：{len(manifest)} 个文件哈希一致；六组内部验收通过；实验验证未完成。")


if __name__ == "__main__":
    main()
